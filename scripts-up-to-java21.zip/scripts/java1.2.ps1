javaX "Java 1.2" $args[0]
