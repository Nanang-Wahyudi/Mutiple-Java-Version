javaX "Java 17" $args[0]
