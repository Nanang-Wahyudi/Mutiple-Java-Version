javaX "Java 5" $args[0]
