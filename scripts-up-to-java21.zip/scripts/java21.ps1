javaX "Java 21" $args[0]
