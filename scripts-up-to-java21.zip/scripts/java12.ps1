javaX "Java 12" $args[0]
