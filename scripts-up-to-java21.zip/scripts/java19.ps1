javaX "Java 19" $args[0]
