javaX "Java 10" $args[0]
