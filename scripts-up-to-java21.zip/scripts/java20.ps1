javaX "Java 20" $args[0]
